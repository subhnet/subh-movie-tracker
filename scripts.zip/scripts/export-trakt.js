/**
 * Export the tracker CSVs into Trakt's CSV import format.
 *
 * Trakt's importer is ID-only, so each title is resolved to a TMDB id first.
 *
 * Usage: npm run export-trakt
 * Needs TMDB_API_KEY in .env / .env.local.
 *
 * Output (exports/trakt/):
 *   trakt-watched.csv    watched movies, with watched_at and your rating
 *   trakt-watchlist.csv  the Must want-to-watch list (movies and shows), watchlist only
 *   trakt-shows.csv      the Must shows list, rated and added to the watchlist (no episode data exists)
 *   unmatched.csv        titles with no exact TMDB title match (with closest guess) - fix by hand
 */

const fs = require('fs');
const path = require('path');
const { ROOT, collectItems, toCsv, validRating, UNMATCHED_HEADER } = require('./lib/tmdb-resolve');

const OUT_DIR = path.join(ROOT, 'exports', 'trakt');
const HEADER = ['tmdb_id', 'type', 'watched_at', 'watchlisted_at', 'rating', 'rated_at'];
const NOW = new Date().toISOString().replace(/\.\d{3}Z$/, 'Z');

async function main() {
  const { items, unmatched } = await collectItems();
  fs.mkdirSync(OUT_DIR, { recursive: true });

  const out = { watched: [], watchlist: [], shows: [] };
  const review = [];
  const seen = new Set();

  for (const item of items) {
    const { list, type, match, row } = item;
    const rating = validRating(row.rating);
    const date = (row.watchedDate || '').trim();
    const out_row = { tmdb_id: match.id, type };

    if (list === 'watched') {
      out_row.watched_at = date ? `${date}T00:00:00Z` : 'unknown';
      out_row.rating = rating;
      if (rating) out_row.rated_at = date ? `${date}T00:00:00Z` : NOW;
    } else if (list === 'wants') {
      out_row.watchlisted_at = NOW;
    } else {
      out_row.watchlisted_at = NOW;
      out_row.rating = rating;
      if (rating) out_row.rated_at = NOW;
    }

    const dedupeKey = `${list}|${type}|${match.id}|${out_row.watched_at || ''}`;
    if (seen.has(dedupeKey)) continue;
    seen.add(dedupeKey);

    out[list === 'wants' ? 'watchlist' : list === 'watched' ? 'watched' : 'shows'].push(out_row);
    review.push(reviewRow(item));
  }

  fs.writeFileSync(path.join(OUT_DIR, 'trakt-watched.csv'), toCsv(HEADER, out.watched));
  fs.writeFileSync(path.join(OUT_DIR, 'trakt-watchlist.csv'), toCsv(HEADER, out.watchlist));
  fs.writeFileSync(path.join(OUT_DIR, 'trakt-shows.csv'), toCsv(HEADER, out.shows));
  fs.writeFileSync(path.join(OUT_DIR, 'unmatched.csv'), toCsv(UNMATCHED_HEADER, unmatched));
  fs.writeFileSync(path.join(OUT_DIR, 'review.csv'), toCsv(REVIEW_HEADER, review));

  console.log(`\nwatched: ${out.watched.length}, watchlist: ${out.watchlist.length}, shows: ${out.shows.length}`);
  console.log(`unmatched (see unmatched.csv): ${unmatched.length}`);
  console.log(`Written to ${path.relative(ROOT, OUT_DIR)}/`);
}

main().catch((err) => {
  console.error(err);
  process.exit(1);
});
